const Discord = require("discord.js");
const moment = require("moment")
const PlayStore = require("google-play-scraper");
const EmbedColor = ``;
moment.locale('pt-br')

module.exports = {
  name: "playstore",
  aliases: ["pstore", "googleplaystore", "ps"],
  description: "Mostrar informações sobre o seu nome no aplicativo da Play Store!",
  usage: "Playstore <Nome da Aplicação>",
  category: "Members",
  run: async (client, message, args) => {
    if (!args[0])
    
      return message.quote(
        `Insira junto com o comando o nome do app ${message.author}`
      
      );

    PlayStore.search({
      term: args.join(" "),
      num: 1
    }).then(Data => {
      let App;

      try {
        App = JSON.parse(JSON.stringify(Data[0]));
      } catch (error) {
        return message.quote(
          `Nenhum aplicativo encontrado ${message.author.username}!`
        );
      }

      let Embed = new Discord.MessageEmbed()
        .setThumbnail(App.icon)
        
        .setURL(App.url)
       
        .setTitle(App.title)
       
        .setDescription(`**Clique [aqui](${App.url}) e faça o Download!**`)
       
        .addField(`Preço:`, App.priceText, true)
        
        .addField(`Desenvolvedor:`, App.developer, true)
        
        .addField(`Avaliação:`, App.scoreText, true)
      
        .setFooter(`${message.author.username}`)
       
        .setTimestamp();

      return message.quote(`${message.author}`, Embed);
    });
  }
};
