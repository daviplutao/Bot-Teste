const Discord = require('discord.js')

module.exports.run = async (client, message, args) => {


  let totalSeconds = client.uptime / 1000;
  let days = Math.floor(totalSeconds / 86400);
  let hours = Math.floor(totalSeconds / 3600);
  totalSeconds %= 3600;
  let minutes = Math.floor(totalSeconds / 60);
  let seconds = totalSeconds % 60;


const embed = new Discord
.MessageEmbed()
.setTitle(`Informações do Helper  ||  Ex - Helper`)
.setDescription(`Olá amigo ${message.author}, me chamo  \`Ex - Helper\`  um bot feito para a  \`Ex - Labs\`.  Fui criado com o intuito de ajudar quem precisa. Para saber mais detalhes consulte meu Desenvolvedor!`)
.addFields(
       {
         name: 'Desenvolvedor  |  Ex - Helper',
         value: `> ID: 559514389292646403\n> Menção: <@559514389292646403>\n> Tag: @S a i t z i m#1500\n`,
         inline: true
       },
       {
         name: 'Conexões  |  Ex - Helper',
         value: `> Membros: ${message.guild.memberCount}\n> Chat Texto: ${message.guild.channels.cache.filter(channel => channel.type === 'text').size}\n> Chat Voz: ${message.guild.channels.cache.filter(channel => channel.type === 'voice').size}`,
         inline: true
       },
       {
         name: 'Status  |  Ex - Helper',
         value: `> Latência: ${Math.round(client.ws.ping)}\n> CPU: ${(process.cpuUsage().system / 1024 / 1024).toFixed(2)}%\n> Memoria RAM: ${(process.memoryUsage().rss / 1024 / 1024).toFixed(2)}Mb\n> Tempo de Atividade: ${days.toFixed()}d, ${hours.toFixed()}hs, ${minutes.toFixed()}min, ${seconds.toFixed()}seg.`
       })

message.quote(`Meu Desenvolvedor: <@559514389292646403>  ||  ${message.author}`, embed)

}