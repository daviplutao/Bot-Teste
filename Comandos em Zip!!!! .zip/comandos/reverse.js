const Discord = require('discord.js')

module.exports.run = async (bot, message, args) => {
 
  try {
    if(!args[0]) {
      return message.reply('Fale Algo Para que eu possa reverter!')  
    }
   
    const str = args.join(` `)
    
    const msg = str.split(``).reverse().join(``)
   
    message.channel.send(`${msg}\n\nComando Realizado por: ${message.author}`)
  
    
  } catch(e) {
    message.channel.send("Ocorreu um erro! "+e)
  }
}