const Discord = require("discord.js")
const config = require('../config.json')
module.exports.run = async (bot, message, args) => {

 if (!message.member.hasPermission("KICK_MEMBERS") && message.author.id !== "780162622314119188") return message.channel.send("Você não tem permissão para utilizar este comando!");
 
 let xdemb = new Discord.MessageEmbed()
 .setTitle("Comando de Expulsam")
 .setDescription(`**Exemplo 1:** ${config.prefix}kick  \`@usuario\`  \`Motivo\` \n**Exemplo 2:** ${config.prefix}kick  \`@Saitzim\`  \`Nao quis cumprir as regras\``)
 
 .setFooter(message.author.username, message.author.displayAvatarURL({dynamic: true, format: 'png'}))
 let member = message.mentions.members.first();
 if(!member) return message.channel.send(xdemb)
 
 if(member.user.id === "786583197247864832") return message.quote("Eu não consigo próprio me expulsar!")
 
 if(member.user.id === "559514389292646403") return message.quote("Não consigo expulsar meu próprio dono!")

if(!member.kickable) 
 return message.quote(`Eu não posso punir o usuário ${member} pois, meu cargo é menor que o do usuário! Para que eu possa punir ela(a) basta colocar meu cargo acima do dele(a), obrigado ${message.author}!`);
 
 let reason = args.slice(1).join(" ");
    if(!reason) {
      return message.quote("Não especificou uma razão!");
    } else {
       var res = reason
    }
 
 await member.kick(reason)
 .catch(error => message.quote(`Eu não conseguir expulsar o usuário pois ele tem permissão de  \`Administração\`!`));

 let kick = new Discord.MessageEmbed()

 .setTitle(member.user.tag)
 .addFields(
      {
         name: "Usuário Punido",
         value: `${member.user.tag}  \`${member.user.id}\``,
         inline: true
      
      },
      {
         
        name: "Motivo",
        value: `${res}`,
        inline: true

      },
      {
         name: "Moderador",
         value: `${message.author} \`${message.author.id}\``,
         inline: true

   })

 .setTimestamp()
 .setFooter(message.author.username, message.author.displayAvatarURL({dynamic: true, format: 'png'}))
 message.quote(`${message.author}`, kick)

 message.delete();
 
}