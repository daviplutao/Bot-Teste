const { MessageEmbed } = require('discord.js');

module.exports = {
    run: async (client, message, args) => {
      
        const region = {
            brazil: 'Brasil',
            europe: 'Europa',
            hongkong: 'Hong Kong',
            india: 'Índia',
            japan: 'Japão',
            russia: 'Rússia',
            singapore: 'Singapore',
            southafrica: 'Africa do Sul',
            sydney: 'sydney',
            uscentral: 'US Central',
            useast: 'US East',
            ussouth: 'US Sul',
            uswest: 'US West'
          }

        const embed = new MessageEmbed()
            .setThumbnail(message.guild.iconURL({dynamic: true}))
            .setDescription(`**[${message.guild.name}](${message.guild.iconURL({size: 2048, format:"png", dynamic : true})})**`)
            .setFooter(`Autor: ${message.author.tag}`)
            
              .addFields(
                {
                  
                  name: "ID do Servidor",
                  value: message.guild.id,
                  inline:true
                
                },
                {
                 
                 name: "Tag do Dono",
                 value: `\`${message.guild.owner.user.tag}\` (${message.guild.owner.user.id})`,
                 inline: true
               
                },
                {
                  
                 name: "Criado em",
                 value: `**${message.guild.createdAt.toLocaleDateString("pt-BR")}**`,
                 inline: true
                 
                },
                {
                  
                 name: "Região",
                 value: region[message.guild.region],
                 inline: true
                  
                },
                {
                 name: `Canais`,
                 value:`Categorias: ${message.guild.channels.cache.filter(c => c.type === 'category').size}\nTexto: ${message.guild.channels.cache.filter(channel => channel.type === 'text').size}\nVoz: ${message.guild.channels.cache.filter(channel => channel.type === 'voice').size}`,
                 inline: true
                  
                },
                {
                  
                  name: "Membros",
                  value: `Existe **${message.guild.memberCount}** Membros aqui no servidor.`,
                  inline: true
                  

                },
                {
                  name: "Cargos do Servidor",
                  value: `Existe **${message.guild.roles.cache.size}** Cargos aqui no servidor.`,
                    inline: true
          
                  
                }
                
            
)
        await message.channel.send(`${message.author}`, embed)
    }
}