const { MessageEmbed } = require('discord.js');
const API = require("../statusconfigs.js")
const moment = require('moment');


module.exports = {
    run: async (client, message, args, chat) => {
		
			const abacate = message.mentions.users.first() || message.author
		
			const corno = message.guild.member(abacate);
  
        let user = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;
        if(!isNaN(args[0])) return message.channel.send('Acho que você se esqueceu de mencionar um usuário válido!') 


const membro = message.mentions.users.first() || message.author

        const embed = new MessageEmbed()
            .setTitle(`Informações do Usuário  |  ${user.user.username}`)
            .setThumbnail(user.user.displayAvatarURL({dynamic : true}))
            .addFields(
                {
                   
                  name: "Tag do Discord:",
                  value: `${user.user.username}#${user.user.discriminator}`,
                    inline: true
                },
                {
                    name: "Apelido:",
                    value: `${user.nickname ? `${user.nickname}` : 'Apelido não encontrado!'}`,
                    inline: true
               
                },
                {
                    name: "ID do Usuário: ",
                    value: `\`${user.user.id}\``,

                },
                {
           
                    name: 'Conta criada em: ',
                    value: `\`${moment.utc(abacate.createdAt).format("lll")}\``,
                    inline: true
                },
                {
                    name: 'Entrou aqui em: ',
                    value:`\`${moment.utc(corno.joinedAt).format("lll")}\``,
                    inline: true
                }
               	
            )
            
            try {
            
            } catch (e) {
                  console.error("Erro:" +e

                  )
            }
  
  await message.channel.send(`${message.author}`, embed)
   
    }
}
