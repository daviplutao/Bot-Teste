const Discord = require('discord.js')

module.exports.run = async (client, message, args) => {

  const embed = new Discord.MessageEmbed()

            .setImage(message.guild.iconURL({size: 2048, format: "png", dynamic : true}))
            .setTitle(`${message.guild.name}  **|**  Ex - Useless`)
            .setDescription(`Clique [aqui](${message.guild.iconURL({size: 2048, format:"png", dynamic : true})}) para abaixar a imagem!`)
            .setFooter(`-- Autor: ${message.author.tag}`, message.author.displayAvatarURL({size: 2048, format: "png", dynamic: true}));
            
    await message.channel.send(`${message.author}`, embed); 

};