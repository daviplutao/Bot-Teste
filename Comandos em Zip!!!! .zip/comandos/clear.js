const Discord = require("discord.js");

exports.run = async (client, message, args) => {
  
  if (!message.member.permissions.has("MANAGE_MESSAGES"))
    return message.channel.send(
      `Falta em você  ${message.author} permissão de  \`Gerenciar Mensagens\``
   
    );
  
  const deleteCount = parseInt(args[0], 10);
  
  if (!deleteCount || deleteCount < 1 || deleteCount > 99)
    return message.channel.send(
      "Forneça um número até 99."
   
    );

  const buscou = await message.channel.messages.fetch({
    limit: deleteCount + 1
  });
  
  message.channel.bulkDelete(buscou);
 
  message.quote(`Foram apagadas ${args[0]} mensagens no canal ${message.channel}, por ${message.author}!`).then(msg => msg.delete({timeout: 7000}))
    
    .catch(error =>
      console.log(`Não foi possível deletar mensagens devido a: ${error}`)
    );
};