const axios = require('axios')

const URL = "https://djsdocs.sorta.moe/v2/embed?src=stable";
module.exports.run = async(client, message, args) => {
    
     
  if(!args[0]) return message.channel.send(`Digite algo para navegar pelas Docs!`)
    
     args = args.splice(0).join(" ");
    
     const qParams = new URLSearchParams({ q: args });
    
     axios.get(URL + `&${qParams.toString()}`).then(response => {
      message.quote(`${message.author}`, { embed: response.data 
        
         })
     })
 };