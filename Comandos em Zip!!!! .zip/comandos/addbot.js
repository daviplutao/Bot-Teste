const Discord = require('discord.js')

module.exports.run = async (client, message, args) => {

    const embeddomal = new Discord.MessageEmbed()

            .setThumbnail(message.guild.iconURL({dynamic : true}))
            .setDescription(`**[Como Adicionar seu Bot aqui no servidor?](http://exbots.glitch.me/)**`)
            .addFields(
               {
                  name: "Primeiro Passo",
                  value: `Para adicionar seu bot no nosso servidor, seu bot precisa ter no mínimo 5 dias de criação. E também tem que ter Botinfo ou algum comando que fala o dono.`,
                  inline: true
                
               },
               {
                 name: "Segundo Passo",
                 value: `Pronto, já que você já sabe daquelas coisas agora vamos colocar a mão na massa! Para adiciona seu seu bot va no site da [Ex - Labs ou Ex - Bots](http://exbots.glitch.me/), como você deseja falar. Depois disso faça login com sua conta Discord. Fazendo Login clique no seu nome no canto direito no topo do site e vá em [Adicionar Bot](https://exbots.glitch.me/add), fazendo isso siga os passos que é GG`,
                 inline: true
                 
               },
               {
                  name: "Terceiro Passo",
                  value: `Agora que você já sabe Adicionar Bots no servidor espere os Verificadores verificarem o seu bot. Obrigado ${message.author} pela atenção!`
               }
              
           )

await message.quote(`${message.author}`, embeddomal)

  }
