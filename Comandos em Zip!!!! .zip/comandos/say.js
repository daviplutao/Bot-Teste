const Discord = require("discord.js")

module.exports.run = async (client, message, args) => {
   
 try {
   
    if (!message.member.permissions.has("MANAGE_MESSAGES"))
    
    return message.reply(
      "Falta em Você Permissão de  \`Gerenciar Mensagens\`"
   
    );

   
   if(!args[0]) {
     const embed = new Discord.MessageEmbed()
     
     .setTitle(`Painel de Ajuda`)
    
     .addFields(
       {
        name: 'Como uso?',
        value: `Utilize o comando acompanhado de uma frase!`,
        inline: true
       },
      
       {
         name: 'Exemplos:',
         value: `1° = <say  \`a Ex - Labs é a melhor botlis existente.\`\n2° = <say  \`Ex - Helper me ajudou muito.\``,
         inline: true
       }
     
     )
     
     return message.channel.send(embed)
  
   }
   
   let dizer = args.join(``);
   
   message.channel.send(`${dizer}\n\nComando realizado por: ${message.author}`)
   
 } 
 
 catch(f) {
     
     message.reply('Ocorreu um erro' +f)
  
 }

}