module.exports.run = async (client, message, args) => {
  const m = await message.quote('Ping ou Pong?');

  m.edit(`Latência do Servidor: **${m.createdTimestamp -
      message.createdTimestamp}ms.**\nPing da API: **${Math.round(
      client.ws.ping
    )}ms**\n\nComando realizado por: ${message.author}`
  );
};