const Discord = require('discord.js');
const { parse } = require('twemoji-parser');

module.exports.run = async (client, message, args) => {
	const emoji = args[0];
	if (!emoji) return message.channel.send('Nenhum emoji foi disponibilizado');

	let custom = Discord.Util.parseEmoji(emoji);

	if (custom.id) {
		const embed = new Discord.MessageEmbed()
			.setTitle(`Emoji do servidor ${message.guild.name}`)
			.setDescription(
				`Gostou do emoji?\n[Clique aqui](https://cdn.discordapp.com/emojis/${custom.id}.${
					custom.animated ? 'gif' : 'png'
				}) para baixa-lo!`
			)
			.setColor('BLUE')
			.setFooter('Gostei do emoji')
			.setTimestamp()
			.setImage(
				`https://cdn.discordapp.com/emojis/${custom.id}.${
					custom.animated ? 'gif' : 'png'
				}`
			);
		return message.quote(embed);
	} else {
		let parsed = parse(emoji, { assetType: 'png' });
		if (!parsed[0]) return message.channel.send(':rikka_nao:Emoji invalido!');
		const embed = new Discord.MessageEmbed()
			.setDescription(`[Clique aqui](${parsed[0].url}) para baixar o emoji`)
			.setColor('BLUE')
			.setImage(parsed[0].url);
		return message.quote(embed);
	}
};
exports.help = {
	name: 'emoji',
	aliases: ['enlarge']
};